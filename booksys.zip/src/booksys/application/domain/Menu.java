package booksys.application.domain;

public class Menu {
	private String menu;
	
	public Menu(String menu) {
		this.menu = menu;
	}
	
	public String getMenu()
	{
		return menu;
	}
}
